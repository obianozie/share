package com.millenium.techtest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.PriorityBlockingQueue;

import com.millenium.techtest.io.Request;
import com.millenium.techtest.io.SocketHandle;
import com.millenium.techtest.io.SocketMessage;
import com.millenium.techtest.processing.AbstractRunnable;
import com.millenium.techtest.processing.ReaderProcess;
import com.millenium.techtest.processing.ResponseDispatcher;
import com.millenium.techtest.processing.ResponseHandler;
import com.millenium.techtest.processing.WriterProcess;

public class Bootstrap {

	public static void main(String[] args) throws InterruptedException {
		Queue<SocketMessage> responseQueue  = new PriorityBlockingQueue<SocketMessage>();
		Map<String, ResponseHandler> requestResponseMap = new ConcurrentHashMap<>();
		Queue<SocketMessage> responses = new PriorityBlockingQueue<>();
		Queue<Request> outboundRequests = new PriorityBlockingQueue<>();
		SocketHandle socketHandle  = initialiseSocketHandle();
		
		final WriterProcess writerProcess = new WriterProcess(requestResponseMap, socketHandle, outboundRequests);		
		final ReaderProcess readerProcess = new ReaderProcess(socketHandle, responses);		
		final ResponseDispatcher dispatcher = new ResponseDispatcher(requestResponseMap, socketHandle, responseQueue, Runtime.getRuntime().availableProcessors());
		
		
		addShutdownHook(writerProcess, readerProcess, dispatcher);		
		final List<Thread> processThreads = startProcesses(writerProcess, readerProcess, dispatcher);
		processThreads.forEach(processThread -> {
			try {
				processThread.join();
			} catch (InterruptedException exce) {
				//log
			}
		});
	}

	private static List<Thread> startProcesses(final AbstractRunnable ...processes) {
		List<Thread> result = new ArrayList<Thread>(processes.length);		
		for (AbstractRunnable runnable : processes) {
			Thread processThread = new Thread(runnable);			
			result.add(processThread);
			processThread.start();
		}
		return result;
	}

	private static void addShutdownHook(
							final WriterProcess writerProcess, 
							final ReaderProcess readerProcess,
							final ResponseDispatcher dispatcher) {
		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			writerProcess.stop();
			readerProcess.stop();
			dispatcher.stop();
		}));
	}

	private static SocketHandle initialiseSocketHandle() {
		// initiatlise socket connection to 3rd party system
		return null;
	}
}