package com.millenium.techtest.io;

import com.millenium.techtest.processing.ResponseHandler;

public class Request {
	
	private SocketMessage message;
	private ResponseHandler responseHandler;
	
	public Request(SocketMessage message, ResponseHandler responseHandler) {
		super();
		this.message = message;
		this.responseHandler = responseHandler;
	}

	public SocketMessage getMessage() {
		return message;
	}

	public ResponseHandler getResponseHandler() {
		return responseHandler;
	}	
}
