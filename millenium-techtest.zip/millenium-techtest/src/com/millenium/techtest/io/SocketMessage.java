package com.millenium.techtest.io;

import java.util.Objects;

public class SocketMessage {
	
	private String requestId;
	private byte[] payload;

	public SocketMessage(String requestId, byte[] payload) {
		super();
		this.requestId = requestId;
		this.payload = payload;
	}

	public String getRequestId() {
		return requestId;
	}

	public byte[] getPayload() {
		return payload;
	}

	@Override
	public int hashCode() {
		return this.requestId.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		boolean result = false;		
		if (obj == this) {
			result = true;
		} else if (obj !=null && obj.getClass().equals(this.getClass())) {
			SocketMessage other = (SocketMessage) obj;
			result = Objects.equals(this.getRequestId(),other.getRequestId());
		}		
		return result;
	}
}
