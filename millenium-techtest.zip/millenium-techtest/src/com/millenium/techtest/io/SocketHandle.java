package com.millenium.techtest.io;

public interface SocketHandle {
	void writeRequest(SocketMessage message);
	SocketMessage readResponse();
}