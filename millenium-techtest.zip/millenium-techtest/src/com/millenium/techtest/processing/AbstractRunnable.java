package com.millenium.techtest.processing;

public abstract class AbstractRunnable implements Runnable {

	private volatile boolean active;

	public AbstractRunnable() {
		stop();
	}

	protected boolean isActive() {
		return active;
	}	
	
	public void start() {
		this.active = true;
	}
	
	public void stop() {
		this.active=false;
	}	
}