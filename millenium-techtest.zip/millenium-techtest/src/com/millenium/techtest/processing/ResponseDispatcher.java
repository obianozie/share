package com.millenium.techtest.processing;

import java.util.Map;
import java.util.Queue;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import com.millenium.techtest.io.SocketHandle;
import com.millenium.techtest.io.SocketMessage;

public class ResponseDispatcher extends AbstractRunnable {

	private final Map<String, ResponseHandler> requestResponseMap;
	private final SocketHandle socketHandle;
	private Executor executor;	
	
	public ResponseDispatcher(
			final Map<String, ResponseHandler> requestResponseMap,
			final SocketHandle socketHandle,
			final Queue<SocketMessage>  responseQueue, 
			final int size) {
		super();
		this.requestResponseMap = requestResponseMap;
		this.socketHandle = socketHandle;
		this.executor = Executors.newFixedThreadPool(size);
	}

	
	@Override
	public void run() {
		while (isActive()) {
			try {
				SocketMessage response = this.socketHandle.readResponse();
				ResponseHandler responseHandler = this.requestResponseMap.remove(response.getRequestId());
				this.executor.execute(() -> responseHandler.onResponse(response));
			} catch (Exception exce) {
				//do some errorhandling or terminate
			}
		}
	}
}
