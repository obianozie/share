package com.millenium.techtest.processing;

import java.util.Queue;

import com.millenium.techtest.io.SocketHandle;
import com.millenium.techtest.io.SocketMessage;

public class ReaderProcess extends AbstractRunnable {

	private SocketHandle socketHandle; 
	private Queue<SocketMessage> responseQueue;
	
	public ReaderProcess( 
			final SocketHandle socketHandle,
			final Queue<SocketMessage> responses) {
		super();
		this.responseQueue = responses;
		this.socketHandle = socketHandle;
	}

	@Override
	public void run() {
		while (this.isActive()) {
			try {
				SocketMessage response = this.socketHandle.readResponse();
				this.responseQueue.add(response);
			} catch (Exception exce) {
				//do some errorhandling or terminate
			}
		}  		
	}

}
