package com.millenium.techtest.processing;

import java.util.Map;
import java.util.Queue;

import com.millenium.techtest.io.Request;
import com.millenium.techtest.io.SocketHandle;

public class WriterProcess extends AbstractRunnable {

	private Map<String, ResponseHandler> requestResponseMap;
	private SocketHandle socketHandle;
	private Queue<Request> inboundRequests;
	
	public WriterProcess(
			final Map<String, ResponseHandler> requestResponseMap, 
			final SocketHandle socketHandle,
			final Queue<Request> outboundRequests) {
		super();
		this.requestResponseMap = requestResponseMap;
		this.socketHandle = socketHandle;
		this.inboundRequests = outboundRequests;
	}

	@Override
	public void run() {
		while (isActive()) {
			try {
				Request request = this.inboundRequests.poll();
				this.requestResponseMap.put(request.getMessage().getRequestId(), request.getResponseHandler());
				this.socketHandle.writeRequest(request.getMessage());
			} catch (Exception exce) {
				//do some errorhandling or terminate
			}
		}  		
	}
}
