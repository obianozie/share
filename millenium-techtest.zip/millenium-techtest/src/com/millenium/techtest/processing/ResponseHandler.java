package com.millenium.techtest.processing;

import com.millenium.techtest.io.SocketMessage;

public interface ResponseHandler {
	void onResponse(final SocketMessage message);
}
